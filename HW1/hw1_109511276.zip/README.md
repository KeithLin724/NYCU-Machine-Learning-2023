# Machine Learn : Linear Regression 
## Written By 練鈞揚 😎
### Py env : Anaconda Py3.11 🐍

---
### File Type
File using : ipyhb 

---

### How to run 🏃

Open in vscode , set the core to be anaconda env = py 3.11 
and run all 

---

### Result 
You can run this program and get the `part1_output.xlsx` in the folder, and you can check the value is it correct 

inside have different sheet need to check it 👍
